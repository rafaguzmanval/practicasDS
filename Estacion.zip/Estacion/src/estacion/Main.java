/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estacion;

import GUI.EstacionGUI;
import GUI.pantallaGUI;
import static GUI.pantallaGUI.observer2;

/**
 *
 * @author jpanequeg
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new pantallaGUI().setVisible(true);
                new EstacionGUI().setVisible(true);
            }
        });
        
        SujetoObservable sujeto = new SujetoObservable();
        hebra1 dos;
         
        dos = new hebra1("Prueba");
        sujeto.addObserver(observer2);
        dos.run(sujeto);
    }
    
}
