/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estacion;

import java.util.Observable;
import java.util.Observer;

/**
 *
 * @author jpanequeg
 */
public class pantallaTemperatura implements Observer
{
    public float f, c;
    public void update(Observable obj, Object arg) 
    {
        
        c = ((Float)arg).floatValue();
        f = (float) ((c*1.8) + 32);
        System.out.println("Pantalla Notified with value centigrados: "+ c);
        System.out.println("Pantalla Notified with value fahrenheit: "+ f);
    }
    
    public float getCentigrados()
    {
        return c;
    }
    
    public float getFahrenheit()
    {
        return f;
    }
}
