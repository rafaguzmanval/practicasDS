/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import estacion.SujetoObservable;
import estacion.graficaTemperatura;
import java.awt.event.ActionListener;
import javax.swing.Timer;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import javax.swing.JFrame;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;


public class Tabla {

    private static final String ROW_KEY = "Valores";
    private int contador = 0;
    public static graficaTemperatura observer1 = new graficaTemperatura();
    public static SujetoObservable sujeto = new SujetoObservable();
    
    
    public void display(graficaTemperatura o1) {
        JFrame f = new JFrame("Tabla");
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        final DefaultCategoryDataset model = new DefaultCategoryDataset();
        model.setValue(o1.temperaturas.get(0), ROW_KEY, "1");
        model.setValue(o1.temperaturas.get(1), ROW_KEY, "2");
        model.setValue(o1.temperaturas.get(2), ROW_KEY, "3");
        model.setValue(o1.temperaturas.get(3), ROW_KEY ,"4");
        model.setValue(o1.temperaturas.get(4), ROW_KEY, "5");
        model.setValue(o1.temperaturas.get(5), ROW_KEY, "6");
        model.setValue(o1.temperaturas.get(6), ROW_KEY, "7");

        JFreeChart chart = ChartFactory.createBarChart("Temperaturas", "Semanas",
            "Valores", model, PlotOrientation.VERTICAL, false, true, false);
        ChartPanel barPanel = new ChartPanel(chart) {

            @Override
            public Dimension getPreferredSize() {
                return new Dimension(320, 240);
            }
        };
        f.add(barPanel);
        new Timer(100, new ActionListener() {
        
            @Override
            public void actionPerformed(ActionEvent e) {
                model.setValue(o1.temperaturas.get(contador%7), ROW_KEY, ""+((contador % 7)+1)+"");
                contador++;
            }
            
        }).start();
        f.pack();
        f.setLocationRelativeTo(null);
        f.setVisible(true);
    }

  
}