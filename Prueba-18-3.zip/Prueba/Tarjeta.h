/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Tarjeta.h
 * Author: emilio
 *
 * Created on 18 de marzo de 2022, 11:13
 */

#ifndef TARJETA_H
#define TARJETA_H

#include "TipoCliente.h"

class Tarjeta : public ComponenteEquipo{
    public:   
    
    Tarjeta();
        
    Tarjeta(double p);
    
    void aceptar(VisitanteEquipo *visitante)override;
    
    double MetodoTarjeta(TipoCliente tipo);
};


#endif /* TARJETA_H */

