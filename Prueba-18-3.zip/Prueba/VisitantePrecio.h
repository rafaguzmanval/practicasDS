/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   VisitantePrecio.h
 * Author: emilio
 *
 * Created on 18 de marzo de 2022, 11:17
 */

#ifndef VISITANTEPRECIO_H
#define VISITANTEPRECIO_H

class VisitantePrecio : public VisitanteEquipo{
    private:
        double costeAcumulado=0;
    public:
        void SumarCoste(double coste);
        
        double DevolverCosteEquipo();
        
        void visitarBus(Bus *b) override;
        
        void visitarTarjeta(Tarjeta *t) override;
        
        void visitarDisco(Disco *d) override;
};

#endif /* VISITANTEPRECIO_H */

