/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include "ComponenteEquipo.h"

   double ComponenteEquipo::getPrecio(){
        return precio;
    }
    
    void ComponenteEquipo::setPrecio(double valor){
        precio = valor;
    }
   
	double ComponenteEquipo::AplicarDescuento(double descuento){
            double precio_aux = precio;
            precio_aux = precio_aux - ((precio_aux*descuento) /100);

            return precio_aux;
	} 
