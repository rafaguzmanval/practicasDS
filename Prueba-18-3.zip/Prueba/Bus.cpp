/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


#include "ComponenteEquipo.h"
#include "Bus.h"
#include "VisitanteEquipo.h"
#include "TipoCliente.h"

    Bus::Bus(){
    	this->setPrecio(10.0);
	 }
    
    Bus::Bus(double p){
   	this->setPrecio(p);
	 }
    
    void Bus::aceptar(VisitanteEquipo *ve){
    	ve->visitarBus(this);
	 }
    
    double Bus::MetodoBus(TipoCliente tipo){
	 	switch(tipo){
                case TipoCliente::SIN_DESCUENTO:
                    return AplicarDescuento(0);
                break;
                
                case TipoCliente::ESTUDIANTE:
                    return AplicarDescuento(10);
                    
                break;
                
                case TipoCliente::MAYORISTA:
                    return AplicarDescuento(15);
                    
            }
	 }

