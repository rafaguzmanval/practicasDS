/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   TipoCliente.h
 * Author: emilio
 *
 * Created on 18 de marzo de 2022, 11:10
 */

#ifndef TIPOCLIENTE_H
#define TIPOCLIENTE_H

enum class TipoCliente{SIN_DESCUENTO, ESTUDIANTE, MAYORISTA};

#endif /* TIPOCLIENTE_H */

