/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: emilio
 *
 * Created on 14 de marzo de 2022, 10:09
 */

#include <cstdlib>
#include <iostream>
#include <string>
#include <iterator>
#include <algorithm>
#include <array>
#include <time.h>
#include "VisitanteEquipo.h"
#include "VisitantePrecio.h"
#include "VisitantePrecioDetalle.h"
#include "ComponenteEquipo.h"
#include "Bus.h"
#include "Tarjeta.h"
#include "Disco.h"
#include "TipoCliente.h"

using namespace std;


void ClientCode(std::array<ComponenteEquipo *, 3> componentes,VisitanteEquipo *visitor){
    for (ComponenteEquipo *comp : componentes){
        comp->aceptar(visitor);
    }
}


/*
 * 
 */
int main(int argc, char** argv) {
    VisitantePrecio *visitor1 = new VisitantePrecio;
    VisitantePrecioDetalle *visitor2 = new VisitantePrecioDetalle;
    double r;
    srand(time(NULL));
    
    for(int i=0; i<10; i++){
        array<ComponenteEquipo *, 3> componentes = {new Bus(50+rand()%(101- 50)), new Disco(50+rand()%(101- 50)), new Tarjeta(50+rand()%(101- 50))};
        
        r = 1+rand()%(4-1);
        if(r ==1){
            visitor1->tipo = TipoCliente::SIN_DESCUENTO;
            visitor2->tipo = TipoCliente::SIN_DESCUENTO;
        }else if (r == 2){
            visitor1->tipo = TipoCliente::ESTUDIANTE;
            visitor2->tipo = TipoCliente::ESTUDIANTE;
        }else{
            visitor1->tipo = TipoCliente::MAYORISTA;
            visitor2->tipo = TipoCliente::MAYORISTA;
        }
        
        ClientCode(componentes, visitor1);
        cout << "Coste del equipo " << i+1 << ":\n" << visitor1->DevolverCosteEquipo() << " euros";

        cout << "\n";
        cout << "Precio detallado de los componentes del equipo " << i+1 << ":\n";
        
        ClientCode(componentes, visitor2);
        
        cout << endl;
        
        for ( ComponenteEquipo *comp : componentes) {
            delete comp;
        }
    }
  
  return 0;
}

