/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include "ComponenteEquipo.h"
#include "Disco.h"
#include "VisitanteEquipo.h"
#include "TipoCliente.h"

Disco::Disco(){
        this->setPrecio(15.0);
    }
        
    Disco::Disco(double p){
        this->setPrecio(p);
    }
    void Disco::aceptar(VisitanteEquipo *ve){
        ve->visitarDisco(this);
    }
    
    double Disco::MetodoDisco(TipoCliente tipo){
        switch(tipo){
                case TipoCliente::SIN_DESCUENTO:
                    return AplicarDescuento(0);
                break;
                
                case TipoCliente::ESTUDIANTE:
                    return AplicarDescuento(10);
                    
                break;
                
                case TipoCliente::MAYORISTA:
                    return AplicarDescuento(15);
                    
            }
    }
