/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Bus.h
 * Author: emilio
 *
 * Created on 18 de marzo de 2022, 10:55
 */

#ifndef BUS_H
#define BUS_H

#include "ComponenteEquipo.h"

enum class TipoCliente;
class VisitanteEquipo;


class Bus: public ComponenteEquipo{
public:
    
    Bus();
    
    Bus(double p);
    
    void aceptar(VisitanteEquipo *ve) override;
    
    double MetodoBus(TipoCliente tipo);

};


#endif /* BUS_H */

