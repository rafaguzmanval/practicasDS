/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include "VisitantePrecioDetalle.h"

#include<iostream>
#include "Bus.h"
#include "Disco.h"
#include "Tarjeta.h"
#include "VisitanteEquipo.h"

using namespace std;



void VisitantePrecioDetalle::visitarBus(Bus* b){
        switch(this->tipo){
            case TipoCliente::SIN_DESCUENTO:
                cout << "Precio Bus: " << b->MetodoBus(this->tipo) << " euros\n";
            break;
                
                case TipoCliente::ESTUDIANTE:
                     cout << "Precio Bus para Estudiante: " << b->MetodoBus(this->tipo) << " euros\n";
                break;
                
                case TipoCliente::MAYORISTA:
                    cout << "Precio Bus para Mayorista: " << b->MetodoBus(this->tipo) << " euros\n";
            }  
        }
        
        void VisitantePrecioDetalle::visitarTarjeta(Tarjeta *t){
            switch(this->tipo){
                case TipoCliente::SIN_DESCUENTO:
                    cout << "Precio Tarjeta: " << t->MetodoTarjeta(this->tipo) << " euros\n";
                break;
                
                case TipoCliente::ESTUDIANTE:
                     cout << "Precio Tarjeta para Estudiante: " << t->MetodoTarjeta(this->tipo) << " euros\n";
                break;
                
                case TipoCliente::MAYORISTA:
                    cout << "Precio Tarjeta para Mayorista: " << t->MetodoTarjeta(this->tipo) << " euros\n";
            }
        }
        
        void VisitantePrecioDetalle::visitarDisco(Disco *d){
            switch(this->tipo){
                case TipoCliente::SIN_DESCUENTO:
                    cout << "Precio Disco: " << d->MetodoDisco(this->tipo) << " euros\n";
                break;
                
                case TipoCliente::ESTUDIANTE:
                     cout << "Precio Disco para Estudiante: " << d->MetodoDisco(this->tipo) << " euros\n";
                break;
                
                case TipoCliente::MAYORISTA:
                    cout << "Precio Disco para Mayorista: " << d->MetodoDisco(this->tipo) << " euros\n";
            }
        } 

