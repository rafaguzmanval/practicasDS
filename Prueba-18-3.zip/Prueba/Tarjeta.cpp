/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


#include "ComponenteEquipo.h"
#include "Tarjeta.h"
#include "VisitanteEquipo.h"
#include "TipoCliente.h"

    Tarjeta::Tarjeta(){
        this->setPrecio(15.0);
    }
        
    Tarjeta::Tarjeta(double p){
        this->setPrecio(p);
    }
    
    void Tarjeta::aceptar(VisitanteEquipo *ve){
        ve->visitarTarjeta(this);
    }
    
    double Tarjeta::MetodoTarjeta(TipoCliente tipo){
        switch(tipo){
                case TipoCliente::SIN_DESCUENTO:
                    return AplicarDescuento(0);
                break;
                
                case TipoCliente::ESTUDIANTE:
                    return AplicarDescuento(10);
                    
                break;
                
                case TipoCliente::MAYORISTA:
                    return AplicarDescuento(15);
                    
            }
    }
