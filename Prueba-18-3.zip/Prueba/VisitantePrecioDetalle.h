/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   VisitantePrecioDetalle.h
 * Author: emilio
 *
 * Created on 18 de marzo de 2022, 11:22
 */

#ifndef VISITANTEPRECIODETALLE_H
#define VISITANTEPRECIODETALLE_H

#include "VisitanteEquipo.h"

class VisitanteEquipo;
class Bus;
class Tarjeta;
class Disco;

class VisitantePrecioDetalle : public VisitanteEquipo{
    public:
        void visitarBus(Bus *b)  override;
        
        void visitarTarjeta(Tarjeta *t) override;
        void visitarDisco(Disco *d) override;
};


#endif /* VISITANTEPRECIODETALLE_H */

