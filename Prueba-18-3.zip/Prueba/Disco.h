/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Disco.h
 * Author: emilio
 *
 * Created on 18 de marzo de 2022, 11:03
 */

#ifndef DISCO_H
#define DISCO_H
#include "ComponenteEquipo.h"
#include "TipoCliente.h"


class Disco : public ComponenteEquipo{
        
    public:
    
    Disco();
        
    Disco(double p);
    
    void aceptar(VisitanteEquipo *visitante)override;
    
    double MetodoDisco(TipoCliente tipo);
};


#endif /* DISCO_H */

