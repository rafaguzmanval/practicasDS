/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ComponenteEquipo.h
 * Author: emilio
 *
 * Created on 18 de marzo de 2022, 10:52
 */

#ifndef COMPONENTEEQUIPO_H
#define COMPONENTEEQUIPO_H
using namespace std;

class VisitanteEquipo;

class ComponenteEquipo{
private:
    double precio;
    
public:
   double getPrecio();
   double AplicarDescuento(double descuento); 
   void setPrecio(double valor);
    
   virtual ~ComponenteEquipo(){}
   virtual void aceptar(VisitanteEquipo *ve) =0;
    
};


#endif /* COMPONENTEEQUIPO_H */

