/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
#include<iostream>
#include "Bus.h"
#include "Disco.h"
#include "Tarjeta.h"
#include "VisitanteEquipo.h"
#include "VisitantePrecio.h"

using namespace std;

        void VisitantePrecio::SumarCoste(double coste){
            costeAcumulado += coste;
        }
        
        double VisitantePrecio::DevolverCosteEquipo(){
            double precio=costeAcumulado;
            costeAcumulado =0;
            return precio;
        }
        
        void VisitantePrecio::visitarBus(Bus *b){
            SumarCoste(b->MetodoBus(this->tipo));
        }
        
        void VisitantePrecio::visitarTarjeta(Tarjeta *t){
            SumarCoste(t->MetodoTarjeta(this->tipo));
   
        }
        
        void VisitantePrecio::visitarDisco(Disco *d){
            SumarCoste(d->MetodoDisco(this->tipo));
               
        }     