/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   VisitanteEquipo.h
 * Author: emilio
 *
 * Created on 17 de marzo de 2022, 16:10
 */

#ifndef VISITANTEEQUIPO_H
#define VISITANTEEQUIPO_H
using namespace std;

class Bus;
class Disco;
class Tarjeta;
enum class TipoCliente;
//#include
class VisitanteEquipo{
    public:
        TipoCliente tipo;
        virtual void visitarBus(Bus *b) = 0;
        virtual void visitarTarjeta(Tarjeta *t)= 0;
        virtual void visitarDisco(Disco *d)  = 0;   
};

#endif /* VISITANTEEQUIPO_H */

