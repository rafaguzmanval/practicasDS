/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


#include "Tarjeta.h"


Tarjeta::Tarjeta()
{
    precio = 10.0;
}

Tarjeta::Tarjeta(double p){
    precio = p;
}

double Tarjeta::getPrecio() {
    return precio;
}

void Tarjeta::setPrecio(double p)
{
    precio = p;
}