/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   VisitanteEquipo.h
 * Author: jpanequeg
 *
 * Created on 13 de marzo de 2022, 11:53
 */

#ifndef VISITANTEEQUIPO_H
#define VISITANTEEQUIPO_H
#include "Bus.h"
#include "Disco.h"
#include "Tarjeta.h"

class VisitanteEquipo{
    
    private:

    
    public:
        
        VisitanteEquipo();
        virtual void visitarBus(Bus b);
        virtual void visitarTarjeta(Tarjeta t);
        virtual void visitarDisco(Disco d);
                
    
};


#endif /* VISITANTEEQUIPO_H */

