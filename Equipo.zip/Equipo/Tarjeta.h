/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Tarjeta.h
 * Author: jpanequeg
 *
 * Created on 13 de marzo de 2022, 11:45
 */

#ifndef TARJETA_H
#define TARJETA_H

class Tarjeta{
    
    private: 
        
        double precio;
        
    public:
       
    Tarjeta();
    
    Tarjeta(double p);
    
    double getPrecio(); 
    
    void setPrecio(double p);
    
};

#endif /* TARJETA_H */

