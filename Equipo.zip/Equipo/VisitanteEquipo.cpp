/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


#include "VisitanteEquipo.h"
#include "Bus.h"
#include "Disco.h"
#include "Tarjeta.h"


VisitanteEquipo::VisitanteEquipo()
{
}


void VisitanteEquipo::visitarBus(Bus b) {

}

void VisitanteEquipo::visitarDisco(Disco d) {

}

void VisitanteEquipo::visitarTarjeta(Tarjeta t) {

}