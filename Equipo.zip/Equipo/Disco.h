/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Disco.h
 * Author: jpanequeg
 *
 * Created on 13 de marzo de 2022, 11:45
 */

#ifndef DISCO_H
#define DISCO_H

class Disco{
    
    private: 
        
        double precio;
        
    public:
        
    Disco();
        
    Disco(double p);
    
    double getPrecio(); 
    
    void setPrecio(double p);
    
};

#endif /* DISCO_H */

