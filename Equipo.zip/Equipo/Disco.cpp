/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include "Disco.h"


Disco::Disco()
{
    precio = 10.0;
}

Disco::Disco(double p){
    precio = p;
}

double Disco::getPrecio() {
    return precio;
}

void Disco::setPrecio(double p)
{
    precio = p;
}