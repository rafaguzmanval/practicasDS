/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Bus.h
 * Author: jpanequeg
 *
 * Created on 13 de marzo de 2022, 11:45
 */

#ifndef BUS_H
#define BUS_H

class Bus{
    
    private: 
        
        double precio;
        
    public:
        
    Bus();
    
    Bus(double p);
    
    double getPrecio();
    
    void setPrecio(double p);
    
};

#endif /* BUS_H */

