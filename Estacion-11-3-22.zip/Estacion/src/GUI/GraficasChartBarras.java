/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GUI;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import static GUI.pantallaGUI.observer2;
import estacion.SujetoObservable;
import estacion.graficaTemperatura;
import estacion.hebra1;
import estacion.pantallaTemperatura;
import java.awt.Graphics;
import java.lang.reflect.InvocationTargetException;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;

/**
 *
 * @author xcheko51x
 */
public class GraficasChartBarras extends JFrame{
    public static graficaTemperatura observer1 = new graficaTemperatura();
    public static pantallaTemperatura observer2 = new pantallaTemperatura();
    public static SujetoObservable sujeto = new SujetoObservable();
    
    
    /*public GraficasChartBarras() {
        
        // Propiedades necesarias para la grafica
        CategoryDataset dataset = createDataset();
        
        JFreeChart chart = ChartFactory.createBarChart(
                "Comparación temperaturas últimas 7 semanas ",
                "Semanas", 
                "Temperaturas", 
                dataset, 
                PlotOrientation.HORIZONTAL,
                true, 
                false, 
                false
        );
        
        ChartPanel panel = new ChartPanel(chart);
        setContentPane(panel);
    
    }*/

    // Datos a mostrar en la grafica
    /*private CategoryDataset createDataset() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        dataset.setValue(observer1.temperaturas.get(0),"rojo" ,"Semana 1");
        dataset.setValue(observer1.temperaturas.get(1), "azul", "Semana 2");

        dataset.setValue(observer1.temperaturas.get(2), "verde", "Semana 3");
        dataset.setValue(observer1.temperaturas.get(3), "amarillo", "Semana 4");

        dataset.setValue(observer1.temperaturas.get(4), "magenta", "Semana 5");
        dataset.setValue(observer1.temperaturas.get(5), "2014", "Semana 6");
        dataset.setValue(observer1.temperaturas.get(6), "2015", "Semana 7");
        
        return dataset;
    }*/
    
    // Comportamiento de la ventana con la grafica
    public static void main(String[] args) throws InterruptedException, InvocationTargetException {
     GraficasChartBarras ejemplo = new GraficasChartBarras();
     int contador=0;
        SwingUtilities.invokeAndWait(()->{          
            ejemplo.setSize(800, 400);
            ejemplo.setLocationRelativeTo(null);
            ejemplo.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
            ejemplo.setVisible(true);
            ejemplo.repaint();
        });
        
        hebra1 uno ;
        
        uno = new hebra1("Prueba");
        
        sujeto.addObserver(observer1);
        sujeto.addObserver(observer2);
        
        uno.run(sujeto);
    }
    
    public void paint(Graphics g){
        super.paint(g);
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.setValue(observer1.temperaturas.get(0),"rojo" ,"Semana 1");
        dataset.setValue(observer1.temperaturas.get(1), "azul", "Semana 2");

        dataset.setValue(observer1.temperaturas.get(2), "verde", "Semana 3");
        dataset.setValue(observer1.temperaturas.get(3), "amarillo", "Semana 4");

        dataset.setValue(observer1.temperaturas.get(4), "magenta", "Semana 5");
        dataset.setValue(observer1.temperaturas.get(5), "2014", "Semana 6");
        dataset.setValue(observer1.temperaturas.get(6), "2015", "Semana 7");
        
        JFreeChart chart = ChartFactory.createBarChart(
                "Comparación temperaturas últimas 7 semanas ",
                "Semanas", 
                "Temperaturas", 
                dataset, 
                PlotOrientation.HORIZONTAL,
                true, 
                false, 
                false
        );
        
        ChartPanel panel = new ChartPanel(chart);
        setContentPane(panel);
        

        
        
        repaint();
    }
    
    
}