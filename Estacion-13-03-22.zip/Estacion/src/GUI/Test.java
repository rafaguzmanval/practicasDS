/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import static GUI.GraficasChartBarras.observer1;
import static GUI.GraficasChartBarras.observer2;
import static GUI.GraficasChartBarras.sujeto;
import estacion.SujetoObservable;
import estacion.graficaTemperatura;
import estacion.hebra1;
import estacion.pantallaTemperatura;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

/*
public class Test {

    private static final int N = 128;
    private static final Random random = new Random();
    private int n = 1;
    private int contador = 0;
    public static graficaTemperatura observer1 = new graficaTemperatura();
    public static pantallaTemperatura observer2 = new pantallaTemperatura();
    public static SujetoObservable sujeto = new SujetoObservable();
    public static CategoryDataset dataset = new DefaultCategoryDataset();
    
    private CategoryDataset createDataset() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        dataset.setValue(observer1.temperaturas.get(0),"rojo" ,"Semana 1");
        dataset.setValue(observer1.temperaturas.get(1), "azul", "Semana 2");

        dataset.setValue(observer1.temperaturas.get(2), "verde", "Semana 3");
        dataset.setValue(observer1.temperaturas.get(3), "amarillo", "Semana 4");

        dataset.setValue(observer1.temperaturas.get(4), "magenta", "Semana 5");
        dataset.setValue(observer1.temperaturas.get(5), "2014", "Semana 6");
        dataset.setValue(observer1.temperaturas.get(6), "2015", "Semana 7");
        
        return dataset;
    }
    
    private void display() {
        JFrame f = new JFrame("TabChart");
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel p = new JPanel(new GridLayout(0, 1));
        //for (int i = 0; i < 3; i++) {
            p.add(createPane());
        //}
        f.add(p, BorderLayout.CENTER);
        f.pack();
        f.setLocationRelativeTo(null);
        f.setVisible(true);
    }

    private ChartPanel createPane() {
        //final XYSeries series = new XYSeries("Data");
        
        //for (int i = 0; i < 7; i++) {
          //  series.add(i, observer1.temperaturas.get(i));
        //}
       // XYSeriesCollection dataset = new XYSeriesCollection(series);
        dataset= createDataset();
        new Timer(2000, new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                //series.add(contador%7, observer1.temperaturas.get(contador%7));
                //series.updateByIndex(contador%7, observer1.temperaturas.get(contador%7));
                //contador++;
                dataset = createDataset();
            }
        }).start();
            JFreeChart chart = ChartFactory.createBarChart(
                "Comparación temperaturas últimas 7 semanas ",
                "Semanas", 
                "Temperaturas", 
                dataset, 
                PlotOrientation.HORIZONTAL,
                true, 
                false, 
                false
        );
          
        return new ChartPanel(chart) {
            @Override
            public Dimension getPreferredSize() {
                return new Dimension(480, 240);
            }
        };
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Test().display();
            }
        });
        
        hebra1 uno ;
        
        uno = new hebra1("Prueba");
        
        sujeto.addObserver(observer1);
        sujeto.addObserver(observer2);
        
        uno.run(sujeto);
    }
}
*/

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.util.Random;
import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JFrame;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

/**
 * @see https://stackoverflow.com/a/21267585/230513
 */
public class Test {

    private static final String ROW_KEY = "Values";
    private static final Random r = new Random();
    private int contador = 0;
    public static graficaTemperatura observer1 = new graficaTemperatura();
    public static pantallaTemperatura observer2 = new pantallaTemperatura();
    public static SujetoObservable sujeto = new SujetoObservable();
    
    
    private void display() {
        JFrame f = new JFrame("Test");
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        final DefaultCategoryDataset model = new DefaultCategoryDataset();
        model.setValue(observer1.temperaturas.get(0), ROW_KEY, "1");
        model.setValue(observer1.temperaturas.get(1), ROW_KEY, "2");
        model.setValue(observer1.temperaturas.get(2), ROW_KEY, "3");
        model.setValue(observer1.temperaturas.get(3), ROW_KEY ,"4");
        model.setValue(observer1.temperaturas.get(4), ROW_KEY, "5");
        model.setValue(observer1.temperaturas.get(5), ROW_KEY, "6");
        model.setValue(observer1.temperaturas.get(6), ROW_KEY, "7");

        JFreeChart chart = ChartFactory.createBarChart("Proxi", "Sensors",
            "Value", model, PlotOrientation.VERTICAL, false, true, false);
        ChartPanel barPanel = new ChartPanel(chart) {

            @Override
            public Dimension getPreferredSize() {
                return new Dimension(320, 240);
            }
        };
        f.add(barPanel);
        //f.add(new JButton(new AbstractAction("Update") {
        new Timer(2000, new ActionListener() {
        
            @Override
            public void actionPerformed(ActionEvent e) {
                model.setValue(observer1.temperaturas.get(contador%7), ROW_KEY, ""+((contador % 7)+1)+"");
                //model.se
                //series.add(contador%7, observer1.temperaturas.get(contador%7));
                //series.updateByIndex(contador%7, observer1.temperaturas.get(contador%7));
                contador++;
            }
        //}), BorderLayout.SOUTH);
        }).start();
        f.pack();
        f.setLocationRelativeTo(null);
        f.setVisible(true);
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {

            @Override
            public void run() {
                new Test().display();
            }
        });
        hebra1 uno ;
        
        uno = new hebra1("Prueba");
        
        sujeto.addObserver(observer1);
        sujeto.addObserver(observer2);
        
        uno.run(sujeto);
    }
}