/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: emilio
 *
 * Created on 14 de marzo de 2022, 10:09
 */

#include <cstdlib>
#include <iostream>
#include <string>
#include <iterator>
#include <algorithm>
#include <array>
#include <time.h>

using namespace std;

class Bus;
class Disco;
class Tarjeta;


class VisitanteEquipo{
    public:
        virtual void visitarBus(const Bus *b) = 0;
        virtual void visitarTarjeta(const Tarjeta *t)= 0;
        virtual void visitarDisco(const Disco *d)  = 0;
                
    
};


class ComponenteEquipo{
    
    public:
        virtual ~ComponenteEquipo(){}
        virtual void aceptar(VisitanteEquipo *ve) const =0;
    
};

class Bus: public ComponenteEquipo{
    
    private:     
        double precio;
        
    public:
        
    Bus(){
        precio = 10.0;
    }
    
    Bus(double p){
        precio = p;
    }
    
    void aceptar(VisitanteEquipo *visitante) const override{
        visitante->visitarBus(this);
    }
    
    double MetodoBus() const{
        return precio;
    }
};


class Disco : public ComponenteEquipo{
    
    private: 
        
        double precio;
        
    public:
        
    Disco(){
        precio = 15.0;
    }
        
    Disco(double p){
        precio = p;
    }
    
    void aceptar(VisitanteEquipo *visitante) const override{
        visitante->visitarDisco(this);
    }
    
    double MetodoDisco() const{
        return precio;
    }
};


class Tarjeta : public ComponenteEquipo{
    
    private: 
        
        double precio;
        
    public:
       
    Tarjeta(){
        precio = 15.0;
    }
        
    Tarjeta(double p){
        precio = p;
    }
    
    void aceptar(VisitanteEquipo *visitante) const override{
        visitante->visitarTarjeta(this);
    }
    
    double MetodoTarjeta() const{
        return precio;
    }
};

class VisitantePrecio : public VisitanteEquipo{
    private:
        double costeAcumulado=0;
    public:
        void SumarCoste(double coste){
            costeAcumulado += coste;
        }
        
        double DevolverCosteEquipo(){
            double precio=costeAcumulado;
            costeAcumulado =0;
            return precio;
        }
        
        void visitarBus(const Bus *b) override{
            SumarCoste(b->MetodoBus());
        }
        
        void visitarTarjeta(const Tarjeta *t) override{
            SumarCoste( t->MetodoTarjeta());
        }
        
        void visitarDisco(const Disco *d) override{
            SumarCoste(d->MetodoDisco());
        }
        
        
};


class VisitantePrecioDetalle : public VisitanteEquipo{
    public:
        void visitarBus(const Bus *b)  override{
            cout << "Precio Bus: " << b->MetodoBus() << " euros\n";
        }
        
        void visitarTarjeta(const Tarjeta *t) override{
            cout << "Precio Tarjeta: " << t->MetodoTarjeta() << " euros\n";
    }
        
    void visitarDisco(const Disco *d) override{
        cout << "Precio Disco: " << d->MetodoDisco() << " euros\n";
    } 
};


void ClientCode(std::array<const ComponenteEquipo *, 3> componentes,VisitanteEquipo *visitor){
    for (const ComponenteEquipo *comp : componentes){
        comp->aceptar(visitor);
    }
}


/*
 * 
 */
int main(int argc, char** argv) {
    VisitantePrecio *visitor1 = new VisitantePrecio;
    VisitantePrecioDetalle *visitor2 = new VisitantePrecioDetalle;
    double r;
    
    srand(time(NULL));
    
     r = 1+rand()%(101- 50);
    
    for(int i=0; i<5; i++){
        array<const ComponenteEquipo *, 3> componentes = {new Bus(50+rand()%(101- 50)), 
                                                        new Disco(50+rand()%(101- 50)), 
                                                        new Tarjeta(50+rand()%(101- 50))};

        ClientCode(componentes, visitor1);
        cout << "Coste del equipo " << i+1 << ":\n" << visitor1->DevolverCosteEquipo() << " euros";

        cout << "\n";
        cout << "Precio detallado de los componentes del equipo " << i+1 << ":\n";
    
        ClientCode(componentes, visitor2);
        
        cout << endl;
        
        for (const ComponenteEquipo *comp : componentes) {
            delete comp;
        }
    }
    
    
    
    
    
    
    
    
    
    
    
    
    delete visitor1;
    delete visitor2;
  
  return 0;
}

